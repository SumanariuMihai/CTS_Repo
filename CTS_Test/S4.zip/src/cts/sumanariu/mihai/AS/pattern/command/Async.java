package cts.sumanariu.mihai.AS.pattern.command;

public class Async implements IAsync{

	@Override
	public void awaitTask() {
		
	}

}
