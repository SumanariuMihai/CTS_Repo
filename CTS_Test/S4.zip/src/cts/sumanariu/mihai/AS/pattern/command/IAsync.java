package cts.sumanariu.mihai.AS.pattern.command;

public interface IAsync {
	
	public void awaitTask();
	
}
