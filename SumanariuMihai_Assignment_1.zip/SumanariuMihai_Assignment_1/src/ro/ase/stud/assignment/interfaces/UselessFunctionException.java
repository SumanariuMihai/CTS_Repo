package ro.ase.stud.assignment.interfaces;

public class UselessFunctionException extends Exception {

}
