package ro.ase.stud.assignment.interfaces;

public interface MonthlyRateGettable {
	
	public double getRate();
}
