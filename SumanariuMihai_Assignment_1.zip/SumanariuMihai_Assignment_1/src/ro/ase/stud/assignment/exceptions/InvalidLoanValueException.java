package ro.ase.stud.assignment.exceptions;

public class InvalidLoanValueException extends Exception {

}
