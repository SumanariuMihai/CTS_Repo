package ro.ase.stud.assignment.classes.outsourcedServices;

public class BrokerServices {

	float brokerFee;
	
	public BrokerServices() {
		this.brokerFee=0.125f;
	}
	
	public float getBrokerFee() {
		return this.brokerFee;
	}
}
