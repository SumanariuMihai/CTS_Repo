package sumanariu.mihai.gr1094.SupplYear.Factory;

public class TextField extends AbstractField {
	
	protected String text;
	
	public TextField(String description, String text) {
		this.text=text;
		this.description=description;
	}
	
	
}
