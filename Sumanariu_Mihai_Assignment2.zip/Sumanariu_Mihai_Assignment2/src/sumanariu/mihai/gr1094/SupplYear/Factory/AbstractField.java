package sumanariu.mihai.gr1094.SupplYear.Factory;

public abstract class AbstractField {

	protected String description;
	
	public void setDescription(String description) {
		this.description=description;
	}
	
}
