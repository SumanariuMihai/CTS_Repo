package sumanariu.mihai.gr1094.SupplYear.Adapter;

public interface MarketingActions {
	
	public int computeAverage(int sum);
	public String getDescription();
	public void setDescription(String description);
	public void Add(int newElem);
	public int sumUp();
	
}
